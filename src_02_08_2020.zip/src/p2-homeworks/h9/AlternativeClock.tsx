import React from 'react'

function AlternativeClock() {


    return (
        <div>

        </div>
    )
}

export default AlternativeClock
