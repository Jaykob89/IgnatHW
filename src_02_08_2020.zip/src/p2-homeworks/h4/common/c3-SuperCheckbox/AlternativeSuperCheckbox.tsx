import React from 'react'

function AlternativeSuperCheckbox() {
    return (
        <input/>
    )
}

export default AlternativeSuperCheckbox
