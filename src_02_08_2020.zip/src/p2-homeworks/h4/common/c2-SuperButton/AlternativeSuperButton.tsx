import React from 'react'

function AlternativeSuperButton() {
    return (
        <button/>
    )
}

export default AlternativeSuperButton
