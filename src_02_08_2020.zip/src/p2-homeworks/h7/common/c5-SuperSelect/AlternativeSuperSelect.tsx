import React from 'react'

function AlternativeSuperSelect() {
    return (
        <input/>
    )
}

export default AlternativeSuperSelect
